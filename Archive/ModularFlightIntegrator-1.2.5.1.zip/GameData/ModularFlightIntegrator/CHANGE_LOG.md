# Modular Flight Integrator :: Change Log

* 2018-1019: 1.2.5.1 (Lisias) for KSP 1.4
	+ I goofed horribly on 1.2.4.10. Ungoofing... 
	+ Bumping version to match upstream's
* 2018-1008: 1.2.4.10 (Lisias) for KSP 1.4
	+ Some braindead optimizations on the code
	+ Adding [KSPe](https://github.com/net-lisias-ksp/KSPAPIExtensions) logging facilities
		- Hard dependency
	+ "Locking" up KSP support to the 1.4 series
		- At least until I test it on the previous ones
* 2018-0814: 1.2.4.9 (Lisias) for KSP 1.4.x
	+ Merged Angel-125 changes
	+ Compiled for KSP 1.4.1 and beyound
* 2017-0322: 1.2.4.8 (Sarbian) for KSp 1.2.2
	+ Fix some bugs reported by @eggrobin
	+ Remove debug spam
	+ Change for Principia 
